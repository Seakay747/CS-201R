#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

void printMenu();

void printCustomerData(struct Account arr[], int size);

void printNames(struct Account arr[], int size);

void printBankTotal(struct Account arr[], int size);

